import React from "react";
import "./css/style.css";
import "bootstrap/dist/css/bootstrap.min.css";
import ReactDOM from "react-dom";
import App from "./components/App";
import projectrout from "./Projectrout";
//console.log(React);
//console.log(ReactDOM);

import { createBrowserRouter, RouterProvider } from "react-router-dom";
const result = ReactDOM.createRoot(document.getElementById("root"));
// result.render("Hello Mendak..!");

// var username = "kajal";
// var age = 23;

// result.render(
//     <ul>
//         <li>{username}</li>
//         <li>{age}</li>
//     </ul>
// );

//result.render(<App />);
result.render(<RouterProvider router={projectrout} />);
// result.render("test");
