import React from "react";

const contextAPI = React.createContext();
export default contextAPI;