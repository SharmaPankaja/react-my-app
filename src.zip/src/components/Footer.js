import React from "react";

function Footer() {
  return <div class="footer"> Design by: Pankaja</div>;
}

export default Footer;
