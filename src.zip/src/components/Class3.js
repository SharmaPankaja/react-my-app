import React from "react";

class Class3 extends React.Component {
  constructor() {
    super();
    console.log(this);

    this.state = {
      name: "Pankaja",
      age: 24,
    };
  }

  f1() {
    this.setState({
      name: "Sharma",
    });
    }
    
    f2() {
        this.setState({
            age:this.setState.age+5,
        });
    }

    componentDidMount() {
        console.log("did mouint cycle called!",this.state.name,this.state.age);
    }
    
    componentDidUpdate() {
        console.log("did update cycle called!", this.state.name, this.state.age);
    }

    componentWillUnmount() {
        console.log("Leaving component");
    }
  render() {
    return (
      <div className="container">
        <h1>Life Cycle Hook</h1>
        <p>{this.state.name}</p>
        <button
          onClick={() => {
            this.f1();
          }}
        >
          Change name
        </button>
        <p>{this.state.age}</p>
        <button
          onClick={() => {
            this.f2();
          }}
        >
          Change age
        </button>
      </div>
    );
  }
}

export default Class3;
