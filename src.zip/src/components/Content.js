import React from "react";
import Product from "./Product";
function Content() {
  return (
    <div className="container">
      <div className="row">
        <div className="col-xl-3">
          <Product name="Nike" price="1399" />
        </div>
        <div className="col-xl-3">
          <Product name="puma" price="1499" />
        </div>
        <div className="col-xl-3">
          <Product name="Adidas" price="1599" />
        </div>
        <div className="col-xl-3">
          <Product name="Spark" price="1699" />
        </div>
      </div>
    </div>
  );
}

export default Content;
