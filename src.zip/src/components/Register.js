import React, { useEffect, useState } from "react";

export default function Register() {
  var [count, setCount] = useState(100);
  var [name, setName] = useState("Pankaja");

  //when you visited the component useEffect hook get called.
  //if we are changing the State variable then useEffect be recalled.
  //   useEffect(() => {
  //   console.log("useEffect", count, name);
  //});
  //useEffect with empty arr it is called only ones.
  //this is useEffect with conditional variable i.e name.
  //This effect with destructor function.
  //When we leave the useeffect then call the return part.
  useEffect(() => {
    console.log("useEffect", count, name);
    return () => {
      console.log("im leaving ");
    };
  }, []);

  function f1() {
    //alert("Register");
    setCount(count + 100);
  }

  function f2() {
    setName("kaju");
  }

  return (
    <div className="container">
      <h1>State Variable</h1>
      <p>{count}</p>
      <button onClick={f1}>Submit</button>
      <p>{name}</p>
      <button onClick={f2}>Change</button>
    </div>
  );
}
